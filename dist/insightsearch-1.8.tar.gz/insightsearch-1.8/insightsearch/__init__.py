from insightsearch.review  import Analysis
